// Instrucoes: add sub and or addi lw sw (beq j)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h> 
#include "simulador.h"

//funcoes memoria de instrucao

MemoriaInst* alocaMemoriaInst(int tam){
    MemoriaInst* memI;
    memI = (MemoriaInst*) malloc(tam*sizeof(MemoriaInst));
    return memI;
}

void imprimeInstrucao(MemoriaInst *instrucao, int cont, int r){
    
    printf("\nBinario da instrucao %d: %s \n",cont+1, instrucao->binario);

    if(r==1){
          switch (instrucao->tipo) {
        case TipoR:
            printf("opcode: %d \n",  instrucao->op);
            printf("rs: %d \n",  instrucao->rs); 
            printf("rt: %d \n",  instrucao->rt);
            printf("rd: %d \n",  instrucao->rd);
        break;
        case TipoI:
            printf("opcode: %d \n",  instrucao->op);
            printf("rs: %d \n",  instrucao->rs); 
            printf("rt: %d \n",  instrucao->rt);
            printf("imediato : %d \n",  instrucao->imm);
        break;
        case TipoJ:
            printf("opcode: %d \n",  instrucao->op);
            printf("endereço: %d \n",  instrucao->end);
        break;
        default:
            printf("Outro\n");
        break;
          }
    } else if(r==2){
        printf("\n");
    } else {
        printf("Opcao invalida! \n");
    }
}

void imprimeMemoriaInst(MemoriaInst* instrucoes,int tam){
     if (instrucoes == NULL){
                    printf("Memória de instruções vazia...\n");
                }
                else{
                    int r;
                    printf("=====Memória de Instruções=====\n");
                    printf("Deseja visualizar os campos da instrução? \n1 - Sim \n2 - Não \n");
                    scanf("%d", &r);
                    setbuf(stdin, NULL);
                    for(int x = 0; x < tam; x++){
                        imprimeInstrucao(instrucoes+x, x, r);
                        
                    }
                    printf("===============================\n");
                }
}

MemoriaInst recebeInstrucaoR(char *line) {
    MemoriaInst instrucao;
    
    instrucao.imm = 0;
    instrucao.end = 0;

    strcpy(instrucao.binario, line);
    
    strncpy(instrucao.sop, instrucao.binario, 4);
    instrucao.sop[4] = '\0';
    instrucao.op = binParaDec(instrucao.sop);

    strncpy(instrucao.srs, instrucao.binario + 4, 3);
    instrucao.srs[3] = '\0';
    instrucao.rs = binParaDec(instrucao.srs);

    strncpy(instrucao.srt, instrucao.binario + 7, 3);
    instrucao.srt[3] = '\0';
    instrucao.rt = binParaDec(instrucao.srt);

    strncpy(instrucao.srd, instrucao.binario + 10, 3);
    instrucao.srd[3] = '\0';
    instrucao.rd = binParaDec(instrucao.srd);
    
    strncpy(instrucao.sfunct, instrucao.binario + 13, 3);
    instrucao.sfunct[3] = '\0';
    instrucao.funct = binParaDec(instrucao.sfunct);

    instrucao.tipo = TipoR;
    return instrucao;
}

MemoriaInst recebeInstrucaoI(char *line) {
    MemoriaInst instrucao;
    
    instrucao.rd=0;
    instrucao.funct=0;
    instrucao.end=0;

    strcpy(instrucao.binario, line);
    
    strncpy(instrucao.sop, instrucao.binario, 4);
    instrucao.sop[4] = '\0';
    instrucao.op = binParaDec(instrucao.sop);

    strncpy(instrucao.srs, instrucao.binario + 4, 3);
    instrucao.srs[3] = '\0';
    instrucao.rs = binParaDec(instrucao.srs);

    strncpy(instrucao.srt, instrucao.binario + 7, 3);
    instrucao.srt[3] = '\0';
    instrucao.rt = binParaDec(instrucao.srt);

    strncpy(instrucao.simm, instrucao.binario + 10, 6);
    instrucao.simm[6] = '\0';
    instrucao.imm = binParaDec(instrucao.simm);
    
    instrucao.tipo = TipoI;
    
    return instrucao;
}

MemoriaInst recebeInstrucaoJ(char *line) {
    MemoriaInst instrucao;
    
    instrucao.rt =0;
    instrucao.rs =0;
    instrucao.rd =0;
    instrucao.funct =0;
    instrucao.imm =0;
    
    strcpy(instrucao.binario, line);
    
    strncpy(instrucao.sop, instrucao.binario, 4);
    instrucao.sop[4] = '\0';
    instrucao.op = binParaDec(instrucao.sop);
    
    strncpy(instrucao.send, instrucao.binario + 4, 12);
    instrucao.send[12] = '\0';
    instrucao.end = binParaDec(instrucao.send);
    
    instrucao.tipo = TipoJ;
    return instrucao;
}


MemoriaInst* recebeInstrucoes(MemoriaInst* instrucoes){
     
    // Pergunta ao usuário o arquivo a ser carregado
   
    char nome_arquivo[100];
    char line[ins_size+1];
    char buffer[5];
    int opcode;
    int cont = 0;
    printf("Digite o nome do arquivo de instrucoes a ser aberto: \n");
    scanf("%99s", nome_arquivo);
    //strcpy(nome_arquivo,"teste.mem");
    // Abre o arquivo
    FILE *file = fopen(nome_arquivo, "r");
    if (!file) {
        printf("Erro ao abrir o arquivo\n");
        //return;
    }

    //O loop vai coletar as instruções em enquanto houver algo nas linhas 
    while (fgets(line, sizeof(line), file)) {
        // Remove caracteres extras como novas linhas e espaços
        line[strcspn(line, "\r\n")] = 0;    
        strncpy(buffer, line, 4);
        buffer[4] = '\0';
        opcode = converteOpCode(buffer);
     
        if(opcode==0){
            *(instrucoes+cont) = recebeInstrucaoR(line);
        } else if (opcode==2){
            *(instrucoes+cont) = recebeInstrucaoJ(line);
        } else if (opcode == 4 || opcode == 8 || opcode == 11 || opcode == 15) {
            *(instrucoes+cont) = recebeInstrucaoI(line);
        }
        
       // Evita armazenar linhas vazias
        if (strlen(line) > 0) {
            cont++;
        }
        //Limita quantas instruções vão ser guardadas no programa
        if (cont >= dataIns_size) {
            break;
        }
    }
    
    printf("Memória de instruções carregada com sucesso...\n");
    instrucoes->total = cont;
    
    fclose(file);
    
}

void SalvarASM(MemoriaInst* instrucoes){
    
    FILE *arquivo = fopen("Arquivo_ASM.asm", "w");

    if (!arquivo) {
        perror("Erro ao criar arquivo .asm");
        return;
    }

    for (int i = 0; i < instrucoes->total; i++) {
        switch ((instrucoes+i)->tipo) {
            case TipoR:
                switch ((instrucoes+i)->funct) {
                    case 0: // ADD
                        fprintf(arquivo, "add $%d, $%d, $%d\n", (instrucoes+i)->rd, (instrucoes+i)->rs, (instrucoes+i)->rt);
                        break;
                    case 2: // SUB
                        fprintf(arquivo, "sub $%d, $%d, $%d\n", (instrucoes+i)->rd, (instrucoes+i)->rs, (instrucoes+i)->rt);
                        break;
                    case 4: // AND
                        fprintf(arquivo, "and $%d, $%d, $%d\n",(instrucoes+i)->rd, (instrucoes+i)->rs, (instrucoes+i)->rt);
                        break;
                    case 5: // OR
                        fprintf(arquivo, "or $%d, $%d, $%d\n", (instrucoes+i)->rd, (instrucoes+i)->rs, (instrucoes+i)->rt);
                        break;
                    default:
                        fprintf(arquivo, "funct invalido: %d\n", (instrucoes+i)->funct);
                        break;
                }
                break;

            case TipoI:
                switch ((instrucoes+i)->op) {
                    case 4: // ADDI
                        fprintf(arquivo, "addi $%d, $%d, %d\n", (instrucoes+i)->rt, (instrucoes+i)->rs, (instrucoes+i)->imm);
                        break;
                    case 8: // BEQ
                        fprintf(arquivo, "beq $%d, $%d, %d\n",(instrucoes+i)->rs, (instrucoes+i)->rt, (instrucoes+i)->imm);
                        break;
                    case 11: // LW
                        fprintf(arquivo, "lw $%d, %d($%d)\n", (instrucoes+i)->rt, (instrucoes+i)->imm, (instrucoes+i)->rs);
                        break;
                    case 15: // SW
                        fprintf(arquivo, "sw $%d, %d($%d)\n", (instrucoes+i)->rt, (instrucoes+i)->imm, (instrucoes+i)->rs);
                        break;
                    default:
                        fprintf(arquivo, "opcode invalido: %d\n", (instrucoes+i)->op);
                        break;
                }
                break;

            case TipoJ:
                switch ((instrucoes+i)->op) {
                    case 2: // JUMP
                        fprintf(arquivo, "j %d\n", (instrucoes+i)->end);
                        break;
                    default:
                        fprintf(arquivo, "opcode invalido: %d\n", (instrucoes+i)->op);
                        break;
                }
                break;

            default:
                fprintf(arquivo, "Instrucao invalida\n");
                break;
        }
    }

    fclose(arquivo);
    printf("Arquivo .asm salvo com sucesso!\n");
}


//funcoes de conversao binario para decimal

int converteOpCode(char *line) {
    int decimal = 0;
     for (int i = 0; i < 4; i++) {
        if (line[i] == '1') {
            decimal += pow(2, 4 - 1 - i);
            //printf("%d \n", decimal);
        } else if (line[i] != '0') {
             printf("Erro: Entrada inválida. Use apenas '0' e '1'.\n");
            return -1;
        }
    }
    return decimal;
}

int binParaDec(char *line) {   
    int decimal = 0;
    int tamanho = strlen(line);
     for (int i = 0; i < tamanho; i++) {
        if (line[i] == '1') {
            decimal += pow(2, tamanho - 1 - i);
        } else if (line[i] != '0') {
             printf("Erro: Entrada inválida. Use apenas '0' e '1'.\n");
            return -1;
        }
    }
    return decimal;
}


//funcoes BancoReg

BancoReg* alocaBancoRegs(int tam){
    BancoReg* banco;
    banco = (BancoReg*) malloc(sizeof(BancoReg));
    banco->regs =  (Reg*) malloc(tam * sizeof(Reg));

    for (int i = 0; i < tam; i++) {
        banco->regs[i].dado = 0;
    }

    banco->RegLido1=0;
    banco->RegLido2=0;
    banco->RegEscrito=0;
    banco->Write=0;
    banco->Saida1=0;
    banco->Saida2=0;
    return banco;
}


void recebeRegs(BancoReg* banco){
    
    int i = 0;
    int buffer;
    FILE *arquivo;
    char nome_arquivor[100];
   // printf("Digite o nome do arquivo de registradores a ser aberto: \n");
   // scanf("%99s", nome_arquivor);
    
    strcpy(nome_arquivor,"numero.txt");
    arquivo = fopen(nome_arquivor, "r");
    
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return;
    }
    
    while (fscanf(arquivo, "%d", &buffer ) == 1 && i < reg_size) {
        (banco->regs+i)->dado = buffer;
        i++;
    }
     fclose(arquivo);
     
     printf("Banco de registradores inicializado com sucesso! \n");
}

void imprimeBancoReg(BancoReg* bancoRegs){
    printf("=====Banco de Registradores=====\n");
     for(int y = 0; y < reg_size; y++){
      printf("R%d: %d\n", y , (bancoRegs->regs+y)->dado);
  }  
   printf("================================\n");

}

void copiaBancoRegs(BancoReg* bancob, BancoReg* banco){
    int i;
    for(i = 0; i < reg_size; i++){
       (bancob->regs+i)->dado = (banco->regs+i)->dado;
    }
}




//funcoes memoria de dados

Mem_dados* alocaMem_dados(int tam){
    Mem_dados* mem_dados;
    mem_dados = (Mem_dados*) malloc(sizeof(Mem_dados));
    mem_dados->dados = (Dados*) malloc(tam * sizeof(Dados));

    for (int i = 0; i < tam; i++) {
        mem_dados->dados[i].dado = 0;
    }

    return mem_dados;
}

void recebeDados(Mem_dados* mem_dados){
    
    int i, j;
    i=j=0;
    int buffer;
    FILE *arquivo;
    char nome_arquivor[100];
    printf("Digite o nome do arquivo da memória de dados a ser aberto\n");
    scanf("%99s", nome_arquivor);
    //strcpy(nome_arquivor,"memoria.dat");
   
    arquivo = fopen(nome_arquivor, "r");
    
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return;
    }
    
    while (fscanf(arquivo, "%d", &buffer ) == 1 && i < data_size) {
        
        if(buffer > (-129) && buffer < 128){
            (mem_dados->dados+j)->dado = buffer;
            j++; 
        } else {
        printf("valor do dado ultrapassa capacidade de representação! \n\n");
        printf("contador i: % d \n contador j: %d \n",i, j);
        }
       i++;
    }

     fclose(arquivo);
     
     printf("Memoria de dados inicializada com sucesso! \n");
}

void imprimeMemDados(Mem_dados* mem_dados){
     int i;
     for(int i = 0; i < data_size; i++){
      printf("conteudo do espaço %d da memória: %d \n", i , (mem_dados->dados+i)->dado);
  }   
}

void copiaBancoMem(Mem_dados* mem_dadosb, Mem_dados* mem_dados){
    int i;
    for(i = 0; i < data_size; i++){
       (mem_dadosb->dados+i)->dado = (mem_dados->dados+i)->dado;
    }
}

//Salva o .dat
void SalvarMemoriaDados(Mem_dados* mem_dados) {
    FILE *arquivo = fopen("memoria.dat", "wb");

    if (!arquivo) {
        perror("Erro ao criar memoria.dat");
        return;
    }
    for (int i = 0; i < data_size; i++){
        fprintf(arquivo, "%d\n", (mem_dados->dados+i)->dado);
    
    }
    
    
    fclose(arquivo);
    printf("Memória salva com sucesso em memoria.dat!\n");
}
// Funcao PC
Pc* alocaMemoriaPC(){
    Pc* pc;
    pc = (Pc*) malloc(sizeof(Pc));
    pc->valor = 0;
    return pc;
}

//Funcoes Ula 

Ula* alocaMemoriaUla(){
    Ula* ula;
    ula = (Ula*) malloc(sizeof(Ula));
    ula->ulaop = 0;
    ula->overflow=0;
    ula->zero=0;
    return ula;
}

int ULA(int ulaop, int operando1, int operando2){
    switch (ulaop) {
        case 0: //ADD
            return operando1 + operando2;
        break;
        case 2: //SUB
            return operando1 - operando2;
        break;
        case 4: //AND
            return operando1 & operando2;
        break;
        case 5: //OR
            return operando1 | operando2;
        break;
    }
}

//funcoes run
void executaInst(MemoriaInst* instrucoes, BancoReg* banco, Ula* ula, Pc* pc, Mem_dados* mem, int x){

if (instrucoes == NULL){
                    printf("Memória de instruções vazia...\n");
                } else{
                        
                                //  imprimeInstrucao(instrucoes+x, x, 2);
                                      
                                printf("\nBinario da instrucao %d: %s \n", x+1, (instrucoes+x)->binario);
                                switch ((instrucoes+x)->tipo) {
                                case TipoR:
                                    switch((instrucoes+x)->funct){
                                                case 0: //000
                                                    printf("ADD $%d ", (instrucoes+x)->rd);
                                                    printf("$%d ", (instrucoes+x)->rs);
                                                    printf("$%d \n", (instrucoes+x)->rt);
                                                    ula->ulaop = (instrucoes+x)->funct;
                                                    banco->RegLido1 = (instrucoes+x)->rs;
                                                    banco->RegLido2 = (instrucoes+x)->rt;
                                                    banco->RegEscrito = (instrucoes+x)->rd;
                                                    if((banco->regs+banco->RegEscrito)!=0){ //Nosso $0 irá SEMPRE ser 0
                                                     (banco->regs+banco->RegEscrito)->dado = ULA(ula->ulaop, (banco->regs+banco->RegLido1)->dado, (banco->regs+banco->RegLido2)->dado);
                                                    }
                                                    pc->valor++;
                                                break;
                                                case 2: //010
                                                    printf("SUB $%d ", (instrucoes+x)->rd);
                                                    printf("$%d ", (instrucoes+x)->rs);
                                                    printf("$%d \n", (instrucoes+x)->rt);
                                                    ula->ulaop = (instrucoes+x)->funct;
                                                    banco->RegLido1 = (instrucoes+x)->rs;
                                                    banco->RegLido2 = (instrucoes+x)->rt;
                                                    banco->RegEscrito = (instrucoes+x)->rd;
                                                    if((banco->regs+banco->RegEscrito)!=0){ //Nosso $0 irá SEMPRE ser 0
                                                     (banco->regs+banco->RegEscrito)->dado = ULA(ula->ulaop, (banco->regs+banco->RegLido1)->dado, (banco->regs+banco->RegLido2)->dado);
                                                    }
                                                    pc->valor++;
                                                break;
                                                case 4: //100
                                                    printf("AND $%d ", (instrucoes+x)->rd);
                                                    printf("$%d ", (instrucoes+x)->rs);
                                                    printf("$%d \n", (instrucoes+x)->rt);
                                                    ula->ulaop = (instrucoes+x)->funct;
                                                    banco->RegLido1 = (instrucoes+x)->rs;
                                                    banco->RegLido2 = (instrucoes+x)->rt;
                                                    banco->RegEscrito = (instrucoes+x)->rd;
                                                    if((banco->regs+banco->RegEscrito)!=0){ //Nosso $0 irá SEMPRE ser 0
                                                     (banco->regs+banco->RegEscrito)->dado = ULA(ula->ulaop, (banco->regs+banco->RegLido1)->dado, (banco->regs+banco->RegLido2)->dado);
                                                    }
                                                  pc->valor++;
                                                break;
                                                case 5: //101
                                                    printf("OR $%d ", (instrucoes+x)->rd);
                                                    printf("$%d ", (instrucoes+x)->rs);
                                                    printf("$%d \n", (instrucoes+x)->rt);
                                                    ula->ulaop = (instrucoes+x)->funct;
                                                    banco->RegLido1 = (instrucoes+x)->rs;
                                                    banco->RegLido2 = (instrucoes+x)->rt;
                                                    banco->RegEscrito = (instrucoes+x)->rd;
                                                    if((banco->regs+banco->RegEscrito)!=0){ //Nosso $0 irá SEMPRE ser 0
                                                     (banco->regs+banco->RegEscrito)->dado = ULA(ula->ulaop, (banco->regs+banco->RegLido1)->dado, (banco->regs+banco->RegLido2)->dado);
                                                    }
                                                   pc->valor++;
                                                break;
                                            }

                                break;
                                
                                case TipoI:
                                    switch ((instrucoes+x)->op) {
                                        case 4: //ADDI
                                        printf("ADDI $%d ", (instrucoes+x)->rt);
                                          printf("$%d ", (instrucoes+x)->rs);
                                          printf("%d \n", (instrucoes+x)->imm);
                                          ula->ulaop = 0;
                                          banco->RegLido1 = (instrucoes+x)->rs;
                                          banco->RegEscrito = (instrucoes+x)->rt;
                                          (banco->regs+banco->RegEscrito)->dado = ULA(ula->ulaop,(banco->RegLido1),(instrucoes+x)->imm);
                                          pc->valor++;
                                        break;
                                        case 8: //1000
                                    
                                        printf("BEQ $%d ",  (instrucoes+x)->rt);
                                        printf("$%d ",  (instrucoes+x)->rs);
                                        printf("%d \n",  (instrucoes+x)->imm);
                                        banco->RegLido1 = (instrucoes+x)->rs;
                                        banco->RegEscrito = (instrucoes+x)->rt;
                                        if (ULA(2, (banco->regs+banco->RegLido1)->dado, (banco->regs+banco->RegEscrito)->dado) == 0){
                                             pc->valor = (pc->valor + 1 + (instrucoes+x)->imm);
                                             // pc->valor =  (instrucoes+x)->imm;
                                        } else {
                                           pc->valor++;
                                        }
                                        
                                    break;
                                        case 11: //LW
                                          printf("LW $%d ", (instrucoes+x)->rt);
                                          printf("$%d ", (instrucoes+x)->rs);
                                          printf("%d \n", (instrucoes+x)->imm);
                                          ula->ulaop = 0;
                                          banco->RegLido1 = (instrucoes+x)->rs;
                                          banco->RegEscrito = (instrucoes+x)->rt;
                                          mem->endereco = ULA(ula->ulaop,(banco->RegLido1),(instrucoes+x)->imm);
                                          mem->dado_lido = (mem->dados+mem->endereco)->dado;
                                          (banco->regs+banco->RegEscrito)->dado = mem->dado_lido;
                                        pc->valor++; 
                                        break;
                                        case 15: //SW
                                          printf("SW $%d ", (instrucoes+x)->rt);
                                          printf("$%d ", (instrucoes+x)->rs);
                                          printf("%d \n", (instrucoes+x)->imm);
                                          ula->ulaop = 0;
                                          banco->RegLido1 = (instrucoes+x)->rs;
                                          banco->RegEscrito = (instrucoes+x)->rt;
                                          mem->endereco = ULA(ula->ulaop,(banco->RegLido1),(instrucoes+x)->imm);
                                          mem->dado_esc = (banco->regs+banco->RegEscrito)->dado; 
                                          (mem->dados+mem->endereco)->dado =  mem->dado_esc;
                                         pc->valor++;
                                        break;
                                    }
                                   
                                break;
                                case TipoJ:
                                   switch ((instrucoes+x)->op) {
                                    case 2: //0010
                                        printf("J $%d\n",  (instrucoes+x)->end);
                                        pc->valor = (instrucoes+x)->end;
                                    break;
                                    
                                }
                                
                                break;
                                default:
                                    printf("Outro\n");
                                break;
                                  } 
                                  
                                printf("PC ATUAL: %d \n\n", pc->valor);
                    printf("===============================\n");
                }
                
    }


// Função para empilhar um elemento
void empilhar(No **topo, Pc* pc, BancoReg* banco, Mem_dados* mem_dados) {
    No *novoNo = (No *)malloc(sizeof(No));
    novoNo->pc = alocaMemoriaPC();
    novoNo->banco = alocaBancoRegs(reg_size);
    novoNo->mem_dados =alocaMem_dados(data_size);
    if (novoNo == NULL) {
        printf("Erro de alocação de memória.\n");
        exit(1);
    }
    novoNo->pc->valor = pc->valor;
    copiaBancoRegs(novoNo->banco, banco);
    copiaBancoMem(novoNo->mem_dados, mem_dados);
   
    novoNo->proximo = *topo;
    *topo = novoNo;
}

// Função para desempilhar um elemento
void desempilhar(No **topo, Pc* pc, BancoReg* banco, Mem_dados* mem_dados) {
    if (*topo == NULL) {
        printf("A pilha está vazia.\n");
        //return -1; // Valor indicativo de erro
    }
    No *temp = *topo;
    copiaBancoRegs(banco, temp->banco);
    copiaBancoMem(mem_dados, temp->mem_dados);
    pc->valor = temp->pc->valor;
    *topo = temp->proximo;
    free(temp);
    
}
