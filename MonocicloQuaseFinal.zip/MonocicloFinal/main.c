// Instrucoes: add sub and or addi lw sw (beq j)

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h> 
#include "simulador.h"

int main()
{
                Pc* pc;
                pc=NULL;
                pc = alocaMemoriaPC();
                printf("valor atual de pc: %d \n", pc->valor);
           
                Ula* ula;
                ula=NULL;
                ula = alocaMemoriaUla();
                
                MemoriaInst* instrucoes;
                instrucoes = NULL;
                instrucoes = alocaMemoriaInst(dataIns_size);
                
                BancoReg* bancoRegs;
                bancoRegs = NULL;
                bancoRegs = alocaBancoRegs(reg_size);
                
                Mem_dados* mem_dados;
                mem_dados = NULL;
                mem_dados = alocaMem_dados(data_size);
                
                No *pilha = NULL;
                
                printf("Simulador inicializado!");
                
    int op_menuprincipal=1;
    while(op_menuprincipal != 0){
            
        printf("\n\n|=====================Menu Principal=====================|\n|0. Sair                                                 |\n|1. Carregar memória de instruções (.mem)                |\n|2. Carregar memória de Dados (.dat)                     |\n|3. Imprimir memórias (instruções e dados)               |\n|4. Imprimir banco de registradores                      |\n|5. Imprimir todo o simulador (registradores e memórias) |\n|6. Salvar .asm                                          |\n|7. Salvar .dat                                          |\n|8. Executa Programa (run)                               |\n|9. Executa uma instrução (Step)                         |\n|10. Volta uma instrução (Back)                          |\n|========================================================|\nEscolha uma opção:\n");
        scanf("%d", &op_menuprincipal);
        switch(op_menuprincipal){
            default:
                printf("Opção Inválida...\n");
            break;
            case 0:
                printf("Saindo...");
            break;
            case 1:
               recebeInstrucoes(instrucoes);
               printf("total de instrucoes: %d  \n\n ", instrucoes->total);
            break;
            case 2:
                // recebeRegs(bancoRegs);
                recebeDados(mem_dados);
            break;
            case 3:
               printf("===============================\n");
               imprimeMemoriaInst(instrucoes, dataIns_size);
               imprimeMemDados(mem_dados);
               printf("===============================\n");
            break;
             case 4:
               printf("===============================\n");
               imprimeBancoReg(bancoRegs);
               printf("===============================\n");
            break;
            case 5:
               printf("===============================\n");
               imprimeMemoriaInst(instrucoes, dataIns_size);
               imprimeMemDados(mem_dados);
               printf("===============================\n");
               printf("===============================\n");
               imprimeBancoReg(bancoRegs);
               printf("===============================\n");
               printf("PC atual: %d \n", pc->valor);
            break;
            case 6:
                SalvarASM(instrucoes);
            break;
            case 7:
                SalvarMemoriaDados(mem_dados);
            break;
            case 8:
                while(pc->valor < instrucoes->total){
                    executaInst(instrucoes, bancoRegs, ula, pc, mem_dados, pc->valor);
                }
                executaInst(instrucoes, bancoRegs, ula, pc, mem_dados, pc->valor);
            break;
            case 9:
                empilhar(&pilha, pc, bancoRegs, mem_dados);
                executaInst(instrucoes, bancoRegs, ula, pc, mem_dados, pc->valor);
            break;
            case 10:
                desempilhar(&pilha, pc, bancoRegs, mem_dados);
                printf("----------------simulador voltou ao estado anterior! ------------------\n PC atual : %d",pc->valor);
            break;
            
            case 11:
            break;
        }
    } 
    return 0;
}