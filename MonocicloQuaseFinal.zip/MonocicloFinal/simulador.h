// Instrucoes: add sub and or addi lw sw (beq j)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h> 


#define dataIns_size 256// Aloca o espaço na memória para criar o vetor de instruções
#define ins_size 17 // 16 bits + 1 para o \0 ou \n
#define reg_size 8 // Numero de Registradores, 3 bits = 8
#define data_size 256

typedef enum {
    TipoR,
    TipoI,
    TipoJ
} TipoInstrucao;

typedef struct {
    char binario[17];
    char sop[5], srs[4], srt[4], srd[4], simm[7], sfunct[4], send[13];
    int op;
    int rs; 
    int rt; 
    int rd;
    int imm; 
    int funct; 
    int end;
    TipoInstrucao tipo;
    int total;
} MemoriaInst;


typedef struct {
    int dado;
} Reg;

typedef struct {
    Reg * regs;
    int RegLido1;
    int RegLido2;
    int RegEscrito;
    int Write;
    int Saida1;
    int Saida2;
} BancoReg;

typedef struct {
    int dado;
} Dados;

typedef struct {
    Dados* dados;
    int ler_mem;
    int esc_mem;
    int endereco;
    int dado_esc;
    int dado_lido;
} Mem_dados;


typedef struct {
   int valor;
} Pc;

typedef struct {
    int ulaop;
    int overflow;
    int zero;
} Ula;

// Estrutura do nó da pilha
typedef struct No {
    Pc* pc;
    Mem_dados* mem_dados;
    BancoReg* banco;
    struct No *proximo;
} No;


//funcoes memoria de instrucao

MemoriaInst * alocaMemoriaInst(int tam);
MemoriaInst* recebeInstrucoes(MemoriaInst* instrucoes);
MemoriaInst recebeInstrucaoR(char *line);
MemoriaInst recebeInstrucaoI(char *line);
MemoriaInst recebeInstrucaoJ(char *line);
void imprimeInstrucao(MemoriaInst *instrucao, int cont, int r);
void imprimeMemoriaInst(MemoriaInst* instrucoes, int tam);
void SalvarASM(MemoriaInst* instrucoes);


//funcoes de conversao binario para decimal

int converteOpCode(char *line);
int binParaDec(char *line);

//funcoes BancoReg

BancoReg* alocaBancoRegs(int tam);
void recebeRegs(BancoReg* banco);
void imprimeBancoReg(BancoReg* bancoRegs);
void copiaBancoRegs(BancoReg* bancob, BancoReg* banco);

//funcoes memoria de dados

Mem_dados* alocaMem_dados(int tam);
void recebeDados(Mem_dados* mem_dados);
void imprimeMemDados(Mem_dados* mem_dados);
void copiaBancoMem(Mem_dados* mem_datab, Mem_dados* dados);
void SalvarMemoriaDados(Mem_dados* mem_dados);



//funcao ula

Pc* alocaMemoriaPC();
Ula* alocaMemoriaUla();
int ULA(int ulaop, int operando1, int operando2);

//controle 
void executaInst(MemoriaInst* instrucoes, BancoReg* banco, Ula* ula, Pc* pc, Mem_dados* mem, int x);

// Função para empilhar um elemento
void empilhar(No **topo, Pc* pc, BancoReg* banco, Mem_dados* mem_dados);

// Função para desempilhar um elemento
void desempilhar(No **topo, Pc* pc, BancoReg* banco, Mem_dados* mem_dados);



