#define Num_Instrucoes 256 // Limite
#define Tam_Instrucao 17 // 16 bits + 1 para o \0
#define NUM_REGISTRADORES 8 // Numero de Registradores, 3 bits = 8
#define Tam_Memoria 256

typedef enum {
    TipoR,
    TipoI,
    TipoJ,
    Outro
} TipoInstrucao;

typedef struct {
    char binario[17];
    int op, rs, rt, rd, imm, funct, end;
    char sop[5], srs[4], srt[4], srd[4], simm[7], sfunct[4], send[13];
    TipoInstrucao tipo;
} Memoria;

typedef struct {
    int pc;
    int registradores[NUM_REGISTRADORES];
    int Memoria_Dados[Tam_Memoria];
    int UlaZero;
    int SinalOverflow;
} Monociclo;

typedef struct {
    int topo;
    Monociclo Estados[Tam_Memoria];
} Pilha_de_Estados;

void Ler_Arquivo(Memoria *instrucoes,int *qtd_instrucoes);
int converteOpCode(char *line);
int binParaDec(char *line);
Memoria recebeInstrucaoR(char *line);
Memoria recebeInstrucaoI(char *line);
Memoria recebeInstrucaoJ(char *line);
void imprimeInstrucao(Memoria *instrucao);
Memoria * alocaMemoria(int tam);
int ULA(int ulaop, int operando1, int operando2,Monociclo *monociclo);
void escrever_registrador(int reg_destino, int valor, Monociclo *monociclo);
void imprimir_registradores(Monociclo *monociclo);
void incrementarpc(Monociclo *monociclo);
void modpc(Monociclo *monociclo, int endereco);
void SalvarMemoriaDados(int memoria[]);
void CarregarMemoriaDados(Monociclo *monociclo);
void SalvarASM(Memoria *instrucoes, int cont);
void controle(Memoria *instrucao, Monociclo *monociclo);
Pilha_de_Estados* inicializaPilha();
void Empilhar(Pilha_de_Estados *pilha, Monociclo *estado);
Monociclo Desempilhar(Pilha_de_Estados *pilha);