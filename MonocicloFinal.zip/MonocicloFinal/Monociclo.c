
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "Monociclo.h"

void Ler_Arquivo(Memoria *instrucoes,int *qtd_instrucoes) {
    char nome_arquivo[100];
    char line[Tam_Instrucao+1];
    int cont_local = 0;

    printf("Digite o nome do arquivo a ser carregado (.mem): ");
    scanf("%99s", nome_arquivo);

    FILE *file = fopen(nome_arquivo, "r");
    if (!file) {
        perror("Erro ao abrir o arquivo");
        //return;
    }

    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\r\n")] = 0;
        if (strlen(line) == 0) continue;

        char buffer[5];
        strncpy(buffer, line, 4);
        buffer[4] = '\0';

        int opcode = converteOpCode(buffer);

        if (opcode == 0) {
            instrucoes[cont_local] = recebeInstrucaoR(line);
        } else if (opcode == 2) {
            instrucoes[cont_local] = recebeInstrucaoJ(line);
        } else if (opcode == 4 || opcode == 8 || opcode == 11 || opcode == 15) {
            instrucoes[cont_local] = recebeInstrucaoI(line);
        } else {
            printf("Instrução inválida ignorada: %s\n", line);
            continue;
        }

        cont_local++;
        if (cont_local >= Num_Instrucoes){ 
            break;
        }
    }

    fclose(file);
    printf("Arquivo carregado com sucesso. %d instruções lidas.\n", cont_local);
    *qtd_instrucoes = cont_local;
}


int converteOpCode(char *line) {
    int decimal = 0;
     for (int i = 0; i < 4; i++) {
        //Vefirica se é 1 e soma o valor em potência de dois
        if (line[i] == '1') {
            decimal += pow(2, 4 - 1 - i);
        } else if (line[i] != '0') {
             printf("Erro: Entrada inválida. Use apenas '0' e '1'.\n");
            return -1;
        }
    }
    return decimal;
}

//Quase a mesma função que a de cima, mas essa tem o tamanho
int binParaDec(char *line) {   
    int decimal = 0;
    int tamanho = strlen(line);
     for (int i = 0; i < tamanho; i++) {
        if (line[i] == '1') {
            decimal += pow(2, tamanho - 1 - i);
        } else if (line[i] != '0') {
             printf("Erro: Entrada inválida. Use apenas '0' e '1'.\n");
            return -1;
        }
    }
    return decimal;
}

//Função que separa a instrução em op/rs/rt/rd/funct
Memoria recebeInstrucaoR(char *line) {
    Memoria instrucao;
    
    instrucao.imm = -1;
    instrucao.end = -1;

    strcpy(instrucao.binario, line);
    
    strncpy(instrucao.sop, instrucao.binario, 4);
    instrucao.sop[4] = '\0';
    instrucao.op = binParaDec(instrucao.sop);

    strncpy(instrucao.srs, instrucao.binario + 4, 3);
    instrucao.srs[3] = '\0';
    instrucao.rs = binParaDec(instrucao.srs);

    strncpy(instrucao.srt, instrucao.binario + 7, 3);
    instrucao.srt[3] = '\0';
    instrucao.rt = binParaDec(instrucao.srt);

    strncpy(instrucao.srd, instrucao.binario + 10, 3);
    instrucao.srd[3] = '\0';
    instrucao.rd = binParaDec(instrucao.srd);
    
    strncpy(instrucao.sfunct, instrucao.binario + 13, 3);
    instrucao.sfunct[3] = '\0';
    instrucao.funct = binParaDec(instrucao.sfunct);

    instrucao.tipo = TipoR;
    return instrucao;
}

//Função que separa a instrução em op/rs/rt/imm
Memoria recebeInstrucaoI(char *line) {
    Memoria instrucao;
    
    instrucao.rd=-1;
    instrucao.funct=-1;
    instrucao.end=-1;

    strcpy(instrucao.binario, line);
    
    strncpy(instrucao.sop, instrucao.binario, 4);
    instrucao.sop[4] = '\0';
    instrucao.op = binParaDec(instrucao.sop);

    strncpy(instrucao.srs, instrucao.binario + 4, 3);
    instrucao.srs[3] = '\0';
    instrucao.rs = binParaDec(instrucao.srs);

    strncpy(instrucao.srt, instrucao.binario + 7, 3);
    instrucao.srt[3] = '\0';
    instrucao.rt = binParaDec(instrucao.srt);

    strncpy(instrucao.simm, instrucao.binario + 10, 6);
    instrucao.simm[6] = '\0';
    instrucao.imm = binParaDec(instrucao.simm);
    
    instrucao.tipo = TipoI;
    
     return instrucao;
}

//Função que separa a instrução em op/address
Memoria recebeInstrucaoJ(char *line) {
    Memoria instrucao;
    
    instrucao.rt =-1;
    instrucao.rs =-1;
    instrucao.rd =-1;
    instrucao.funct = -1;
    instrucao.imm =-1;
    
    strcpy(instrucao.binario, line);
    
    strncpy(instrucao.sop, instrucao.binario, 4);
    instrucao.sop[4] = '\0';
    instrucao.op = binParaDec(instrucao.sop);
    
    strncpy(instrucao.send, instrucao.binario + 4, 12);
    instrucao.send[12] = '\0';
    instrucao.end = binParaDec(instrucao.send);
    
    instrucao.tipo = TipoJ;
     return instrucao;
}

//Imprime cada instrução separando suas 'partes'
void imprimeInstrucao(Memoria *instrucao){
    printf("\n \n  Binario da instrucao: %s \n \n", instrucao->binario);
     switch (instrucao->tipo) {
        case TipoR:
            printf("opcode: %d \n",  instrucao->op);
            printf("rs: %d \n",  instrucao->rs); 
            printf("rt: %d \n",  instrucao->rt);
            printf("rd: %d \n",  instrucao->rd);
        break;
        case TipoI:
            printf("opcode: %d \n",  instrucao->op);
            printf("rs: %d \n",  instrucao->rs); 
            printf("rt: %d \n",  instrucao->rt);
            printf("imediato : %d \n",  instrucao->imm);
        break;
        case TipoJ:
            printf("opcode: %d \n",  instrucao->op);
            printf("endereço: %d \n",  instrucao->end);
        break;
        default:
            printf("Outro\n");
        break;
    }
}

//Alloca memória de instruções
Memoria * alocaMemoria(int tam){
    Memoria* i;
    i = (Memoria*) malloc(tam*sizeof(Memoria));
    return i;
}

//Retorna o valor da operação
int ULA(int ulaop, int operando1, int operando2,Monociclo *monociclo){
    int resultado;
    switch (ulaop) {
        case 0: //ADD
            resultado = operando1 + operando2;
            if(resultado >127 || resultado<-128){
                monociclo->SinalOverflow = 1;
            }else{
                monociclo->SinalOverflow = 0;
            }
            return resultado;
        break;
        case 2: //SUB
            resultado = operando1 - operando2;
            if(resultado >127 || resultado<-128){
                monociclo->SinalOverflow = 1;
            }else{
                monociclo->SinalOverflow = 0;
            }
            if (resultado == 0){
                monociclo->UlaZero = 1;
            }else if (resultado != 0)
            {
                monociclo->UlaZero = 0;
            }
            
            return resultado;
        break;
        case 4: //AND
            return operando1 & operando2;
        break;
        case 5: //OR
            return operando1 | operando2;
        break;
    }
}

//Faz a escrita no registrador
void escrever_registrador(int reg_destino, int valor, Monociclo *monociclo) {
    if (reg_destino != 0) { //Nosso $0 irá SEMPRE ser 0
        monociclo->registradores[reg_destino] = valor;
    }
}

//Imprime todos os registradores
void imprimir_registradores(Monociclo *monociclo) {
    printf("=====Banco de Registradores=====\n");
    for (int i = 0; i < NUM_REGISTRADORES; i++) {
        printf("R%d: %d\n", i, monociclo->registradores[i]);
    }
    printf("================================\n");
}

//Para instruções que não modificam o pc
void incrementarpc(Monociclo *monociclo){
    monociclo->pc++;
}

//Para instruções que modificam o pc
void modpc(Monociclo *monociclo, int endereco){
    monociclo->pc = endereco;
}

//Cérebro do simulador
void controle(Memoria *instrucao, Monociclo *monociclo){
    int auxiliarUla;
    switch(instrucao->op){
        case 0: //0000
            switch(instrucao->funct){
                case 0: //000
                    if(instrucao->rd == 0 && instrucao->rs == 0 && instrucao->rt == 0){
                            printf( "NOP\n");
                            break;
                        }
                    printf("ADD $%d ", instrucao->rd);
                    printf("$%d ", instrucao->rs);
                    printf("$%d \n", instrucao->rt);
                    auxiliarUla = ULA(0, monociclo->registradores[instrucao->rs], monociclo->registradores[instrucao->rt],monociclo);
                    if(monociclo->SinalOverflow == 1){
                        printf("Overflow\n");
                        escrever_registrador(instrucao->rd, auxiliarUla, monociclo);
                    }else{
                        escrever_registrador(instrucao->rd, auxiliarUla, monociclo);
                    }
                break;
                case 2: //010
                    printf("SUB $%d ", instrucao->rd);
                    printf("$%d ", instrucao->rs);
                    printf("$%d \n", instrucao->rt);
                    auxiliarUla = ULA(2, monociclo->registradores[instrucao->rs], monociclo->registradores[instrucao->rt],monociclo);
                    if(monociclo->SinalOverflow == 1){
                        printf("Overflow\n");
                        escrever_registrador(instrucao->rd, auxiliarUla, monociclo);
                    }else{
                        escrever_registrador(instrucao->rd, auxiliarUla, monociclo);
                    }

                break;
                case 4: //100
                    printf("AND $%d ", instrucao->rd);
                    printf("$%d ", instrucao->rs);
                    printf("$%d \n", instrucao->rt);
                    escrever_registrador(instrucao->rd, ULA(4, monociclo->registradores[instrucao->rs], monociclo->registradores[instrucao->rt],monociclo), monociclo);
                break;
                case 5: //101
                    printf("OR $%d ", instrucao->rd);
                    printf("$%d ", instrucao->rs);
                    printf("$%d \n", instrucao->rt);
                    escrever_registrador(instrucao->rd, ULA(5, monociclo->registradores[instrucao->rs], monociclo->registradores[instrucao->rt],monociclo), monociclo);
                break;
            }
        break;
        case 2: //0010
            printf("J $%d\n", instrucao->end);
            modpc(monociclo, instrucao->end - 1);
        break;
        case 4: //0100
            printf("ADDI $%d ", instrucao->rt);
            printf("$%d ", instrucao->rs);
            printf("%d \n", instrucao->imm);
            escrever_registrador(instrucao->rt, ULA(0, monociclo->registradores[instrucao->rs], instrucao->imm,monociclo), monociclo);
        break;
        case 8: //1000
            printf("BEQ $%d ", instrucao->rt);
            printf("$%d ", instrucao->rs);
            printf("%d \n", instrucao->imm);
            ULA(2, monociclo->registradores[instrucao->rt], monociclo->registradores[instrucao->rs],monociclo);
            if (monociclo->UlaZero == 1){
             modpc(monociclo, monociclo->pc + instrucao->imm);
            }
        break;
        case 11: //1011
            printf("LW $%d ",instrucao->rt);
            printf("%d(", instrucao->imm);
            printf("%d) \n", instrucao->rs);
            monociclo->registradores[instrucao->rt] = monociclo->Memoria_Dados[(monociclo->registradores[instrucao->rs]+instrucao->imm)];
        break;
        case 15: //1111
            printf("SW $%d ",instrucao->rt);
            printf("%d(", instrucao->imm);
            printf("%d) \n", instrucao->rs);
            monociclo->Memoria_Dados[(monociclo->registradores[instrucao->rs]+instrucao->imm)] = monociclo->registradores[instrucao->rt];
        break;
    }
}
//Gera o .asm
void SalvarASM(Memoria *instrucoes, int cont){
    
    FILE *arquivo = fopen("Arquivo_ASM.asm", "w");

    if (!arquivo) {
        perror("Erro ao criar arquivo .asm");
        return;
    }

    for (int i = 0; i < cont; i++) {
        //auxilia para não ter confusões de simbolos

        switch (instrucoes[i].tipo) {
            case TipoR:
                switch (instrucoes[i].funct) {
                    case 0: // ADD
                        if(instrucoes[i].rd == 0 && instrucoes[i].rs == 0 && instrucoes[i].rt == 0){
                            fprintf(arquivo, "NOP\n");
                            break;
                        }
                        fprintf(arquivo, "add $%d, $%d, $%d\n", instrucoes[i].rd, instrucoes[i].rs, instrucoes[i].rt);
                        break;
                    case 2: // SUB
                        fprintf(arquivo, "sub $%d, $%d, $%d\n", instrucoes[i].rd, instrucoes[i].rs, instrucoes[i].rt);
                        break;
                    case 4: // AND
                        fprintf(arquivo, "and $%d, $%d, $%d\n", instrucoes[i].rd, instrucoes[i].rs, instrucoes[i].rt);
                        break;
                    case 5: // OR
                        fprintf(arquivo, "or $%d, $%d, $%d\n", instrucoes[i].rd, instrucoes[i].rs, instrucoes[i].rt);
                        break;
                    default:
                        fprintf(arquivo, "funct invalido: %d\n", instrucoes[i].funct);
                        break;
                }
                break;

            case TipoI:
                switch (instrucoes[i].op) {
                    case 4: // ADDI
                        fprintf(arquivo, "addi $%d, $%d, %d\n", instrucoes[i].rt, instrucoes[i].rs, instrucoes[i].imm);
                        break;
                    case 8: // BEQ
                        fprintf(arquivo, "beq $%d, $%d, %d\n", instrucoes[i].rt, instrucoes[i].rs, instrucoes[i].imm);
                        break;
                    case 11: // LW
                        fprintf(arquivo, "lw $%d, %d($%d)\n", instrucoes[i].rt, instrucoes[i].imm, instrucoes[i].rs);
                        break;
                    case 15: // SW
                        fprintf(arquivo, "sw $%d, %d($%d)\n", instrucoes[i].rt, instrucoes[i].imm, instrucoes[i].rs);
                        break;
                    default:
                        fprintf(arquivo, "opcode invalido: %d\n", instrucoes[i].op);
                        break;
                }
                break;

            case TipoJ:
                switch (instrucoes[i].op) {
                    case 2: // JUMP
                        fprintf(arquivo, "j %d\n", instrucoes[i].end);
                        break;
                    default:
                        fprintf(arquivo, "opcode invalido: %d\n", instrucoes[i].op);
                        break;
                }
                break;
            default:
                fprintf(arquivo, "Instrucao invalida\n");
                break;
        }
    }

    fclose(arquivo);
    printf("Arquivo .asm salvo com sucesso!\n");
}
//Memória de Dados 2.0
//Carrega o .dat
void CarregarMemoriaDados(Monociclo *monociclo){
    char nome_arquivo[100];
    printf("Digite o nome do arquivo .dat para carregar: ");
    scanf("%99s", nome_arquivo);

    FILE *arquivo = fopen(nome_arquivo, "rb");
    if (!arquivo) {
        perror("Erro ao abrir o arquivo");
        return;
    }

    fread(monociclo->Memoria_Dados,sizeof(int), 256, arquivo);
    fclose(arquivo);
    printf("Memória carregada de %s !\n", nome_arquivo);
}
//Salva o .dat
void SalvarMemoriaDados(int memoria[]) {
    FILE *arquivo = fopen("memoria.dat", "wb");

    if (!arquivo) {
        perror("Erro ao criar memoria.dat");
        return;
    }

   fwrite(memoria, sizeof(int), 256, arquivo);
   
    fclose(arquivo);
    printf("Memória salva com sucesso em memoria.dat!\n");
}

//Função back vulgo pilha
Pilha_de_Estados* inicializaPilha(){
    Pilha_de_Estados* pilha = (Pilha_de_Estados*)malloc(sizeof(Pilha_de_Estados));
    if (pilha == NULL) {
        perror("Erro ao iniciar pilha");
        exit(1);
    }
    pilha->topo = -1;
    return pilha;
}

void Empilhar(Pilha_de_Estados *pilha, Monociclo *estado) {
    if (pilha->topo >= Tam_Memoria - 1) {
        printf("Erro: pilha cheia, não é possível empilhar mais estados.\n");
        return;
    }
    pilha->topo++;
    pilha->Estados[pilha->topo] = *estado; // Cópia por valor do estado atual
}


Monociclo Desempilhar(Pilha_de_Estados *pilha) {
    if (pilha->topo == -1) {
        printf("Erro: pilha vazia, não é possível desempilhar.\n");
    }

    Monociclo desempilhado = pilha->Estados[pilha->topo];
    pilha->topo--;
    return desempilhado;
}
