#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h> 
#include "Monociclo.h"

int main() {
    int cont = 0;
    Memoria* instrucoes = malloc(sizeof(Memoria) * Num_Instrucoes);
    Monociclo *monociclo = malloc(sizeof(Monociclo));
    monociclo->pc=0;
    monociclo->UlaZero=0;
    Pilha_de_Estados* Pilha_back = inicializaPilha();

    for(int i=0; i<NUM_REGISTRADORES;i++){
        monociclo->registradores[i] = 0;
    }
    for(int i=0; i<Tam_Memoria;i++){
        monociclo->Memoria_Dados[i] = 0;
    }
    for(int i=0; i<Num_Instrucoes; i++){
        strcpy(instrucoes[i].binario, "0000000000000000");
        instrucoes[i].tipo = Outro;
    }

    int op_menuprincipal=1;
    int num_inst=0;
    int op_imprimir_mem_instrucoes=0;
    int op_pc_zero=0;
    while(op_menuprincipal != 0){
        printf("\n\n|=====================Menu Principal=====================|\n|0. Sair                                                 |\n|1. Carregar memória de instruções (.mem)                |\n|2. Carregar memória de Dados (.dat)                     |\n|3. Imprimir memórias (instruções e dados)               |\n|4. Imprimir banco de registradores                      |\n|5. Imprimir todo o simulador (registradores e memórias) |\n|6. Salvar .asm                                          |\n|7. Salvar .dat                                          |\n|8. Executa Programa (run)                               |\n|9. Executa uma instrução (Step)                         |\n|10. Volta uma instrução (Back)                          |\n|========================================================|\nEscolha uma opção:\n");
        scanf("%d", &op_menuprincipal);
        switch(op_menuprincipal){
            default:
                printf("Opção Inválida...\n");
            break;
            case 0:
                printf("Saindo...");
            break;
            case 1:
                if(monociclo->pc != 0){
                    printf("O pc está com o valor de %d, deseja colocar ele pra 0?\n1.Sim\n2.Não\nEscolha uma opção:", monociclo->pc);
                    scanf("%d", &op_pc_zero);
                    switch(op_pc_zero){
                        case 1: 
                            modpc(monociclo, 0);
                        break;
                        default: 
                            printf("Opção Inválida\n"); 
                        break;
                    }
                }
                Ler_Arquivo(instrucoes,&cont);
            break;
            case 2:
                CarregarMemoriaDados(monociclo);
            break;
            case 3:
                if (instrucoes == NULL){
                    printf("Memória de instruções vazia...\n");
                }
                else{
                    printf("Deseja imprimir Toda a Memoria de Instruções?\n1.Sim\n2.Não\nEscolha uma opção:");
                    scanf("%d", &op_imprimir_mem_instrucoes);
                    printf("=====Memória de Instruções=====\n");
                    switch(op_imprimir_mem_instrucoes){
                        case 1:
                            for(int x = 0; x < Num_Instrucoes; x++){
                                imprimeInstrucao(instrucoes+x);
                                
                            }
                        break;
                        case 2:
                            for(int x = 0; x < cont; x++){
                                imprimeInstrucao(instrucoes+x);
                            }
                        break;
                    }
                    printf("===============================\n");
                }
                if(monociclo->Memoria_Dados == NULL){
                    printf("Memória de Dados Vazia");
                }else{
                    printf("=====Memória de Dados=====\n");
                    for(int i = 0;i<Tam_Memoria;i++){
                        printf("[%i] = %i\n",i,monociclo->Memoria_Dados[i]);
                    }
                    printf("===============================\n");
                }
            break;
            case 4:
                imprimir_registradores(monociclo);
            break;
            case 5:
                if (instrucoes == NULL){
                    printf("Memória de instruções vazia...\n");
                }
                else{
                    printf("Deseja imprimir Toda a Memoria de Instruções?\n1.Sim\n2.Não\nEscolha uma opção:");
                    scanf("%d", &op_imprimir_mem_instrucoes);
                    printf("=====Memória de Instruções=====\n");
                    switch(op_imprimir_mem_instrucoes){
                        case 1:
                            for(int x = 0; x < Num_Instrucoes; x++){
                                imprimeInstrucao(instrucoes+x);
                                
                            }
                        break;
                        case 2:
                            for(int x = 0; x < cont; x++){
                                imprimeInstrucao(instrucoes+x);
                            }
                        break;
                    }
                    printf("===============================\n");
                }
                if(monociclo->Memoria_Dados == NULL){
                    printf("Memória de Dados Vazia");
                }else{
                    printf("=====Memória de Dados=====\n");
                    for(int i = 0;i<Tam_Memoria;i++){
                        printf("[%i] = %i\n",i,monociclo->Memoria_Dados[i]);
                    }
                    printf("===============================\n");
                }
                imprimir_registradores(monociclo);
                printf("PC: %d\n", monociclo->pc);
            break;
            case 6:
                SalvarASM(instrucoes, cont);
            break;
            case 7:
                SalvarMemoriaDados(monociclo->Memoria_Dados);
            break;
            case 8:
                while(monociclo->pc < cont){
                    Empilhar(Pilha_back,monociclo);
                    controle(&instrucoes[monociclo->pc], monociclo/*, Pilha_back*/);
                    incrementarpc(monociclo);
                }
            break;
            case 9:
                Empilhar(Pilha_back,monociclo);
                controle(&instrucoes[monociclo->pc], monociclo/*,Pilha_back*/);
                incrementarpc(monociclo);
            break;
            case 10:
                if (monociclo->pc == 0){
                    printf("Não há o que voltar");
                    break;
                }
                *monociclo = Desempilhar(Pilha_back);
            break;
        }
    } 
    free(monociclo);
    return 0;
}
